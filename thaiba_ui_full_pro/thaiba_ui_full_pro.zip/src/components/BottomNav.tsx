
import React from "react";
import { Link, useLocation } from "react-router-dom";
import classNames from "classnames";

export default function BottomNav() {
  const loc = useLocation();

  const nav = [
    { name: "Home", path: "/" },
    { name: "Tasks", path: "/tasks" },
    { name: "Events", path: "/events" },
    { name: "Calendar", path: "/calendar" },
    { name: "Profile", path: "/profile" }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 h-[22px] bg-slate-800 flex justify-around text-xs text-gray-300">
      {nav.map(n => (
        <Link
          key={n.path}
          to={n.path}
          className={classNames(
            "px-2",
            loc.pathname === n.path && "text-yellow-400 font-bold"
          )}
        >
          {n.name}
        </Link>
      ))}
    </div>
  );
}
