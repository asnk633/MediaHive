
import React from "react";
export default function FAB() {
  return (
    <button
      className="fab fixed left-1/2 -translate-x-1/2 bottom-[26px] w-14 h-14 rounded-full bg-indigo-600 text-white text-3xl shadow-xl flex items-center justify-center"
    >
      +
    </button>
  );
}
