
import React from "react";
export default function TopBar() {
  return (
    <header className="sticky top-0 z-10 w-full py-4 px-4 bg-slate-900/90 backdrop-blur shadow">
      <h1 className="font-semibold text-lg">Thaiba Garden Media Manager</h1>
    </header>
  );
}
