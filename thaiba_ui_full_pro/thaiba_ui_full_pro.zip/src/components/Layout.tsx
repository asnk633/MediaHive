
import React from "react";
import { Outlet } from "react-router-dom";
import TopBar from "./TopBar";
import BottomNav from "./BottomNav";
import FAB from "./FAB";

export default function Layout() {
  return (
    <div className="min-h-screen pb-10">
      <TopBar />
      <main className="max-w-6xl mx-auto p-4">
        <Outlet />
      </main>
      <BottomNav />
      <FAB />
    </div>
  );
}
